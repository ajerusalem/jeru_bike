fx_version 'adamant'
author 'jerusalem'

game 'gta5'

lua54 'yes'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

